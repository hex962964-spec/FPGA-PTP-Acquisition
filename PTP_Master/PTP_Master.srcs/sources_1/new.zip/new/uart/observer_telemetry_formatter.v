`timescale 1ns / 1ps
`default_nettype none
//////////////////////////////////////////////////////////////////////////////////
// Module: observer_telemetry_formatter
// -----------------------------------------------------------------------------
// Purpose:
//   Emit a compact ASCII status line for the Observer FPGA over UART.
//
// Current line format:
//   STAT,<uptime>,<rx_frames>,<rx_drops>,<tx_frames>,<flags>,
//        <sync>,<fup>,<timeout>,<seq>,<t1_low>,<rxsync>,
//        <delay_req>,<delay_resp>,<delay_req_drop>,<delay_req_seq>,<delay_req_t4_low>\r\n
//
// All numeric fields are hexadecimal and padded to 8 digits.  The line remains
// intentionally simple CSV-like text; the newly appended fields are bring-up
// visibility for the Delay_Req / Delay_Resp closed-loop path.
//////////////////////////////////////////////////////////////////////////////////
module observer_telemetry_formatter(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start_pulse,

    input  wire [31:0] uptime_s,
    input  wire [31:0] rx_frame_count,
    input  wire [31:0] rx_drop_count,
    input  wire [31:0] tx_frame_count,
    input  wire [7:0]  status_flags,
    input  wire [31:0] ptp_sync_count,
    input  wire [31:0] ptp_follow_up_count,
    input  wire [31:0] ptp_timeout_count,
    input  wire [31:0] ptp_sequence_id,
    input  wire [31:0] ptp_last_t1_low,
    input  wire [31:0] tod_rx_sync_count,
    input  wire [31:0] delay_req_count,
    input  wire [31:0] delay_resp_count,
    input  wire [31:0] delay_req_drop_count,
    input  wire [31:0] delay_req_last_seq,
    input  wire [31:0] delay_req_last_t4_low,

    output reg  [7:0]  m_data,
    output reg         m_valid,
    input  wire        m_ready,
    output wire        busy
);

    localparam [2:0] ST_IDLE   = 3'd0;
    localparam [2:0] ST_PREFIX = 3'd1;
    localparam [2:0] ST_FIELD  = 3'd2;
    localparam [2:0] ST_COMMA  = 3'd3;
    localparam [2:0] ST_CR     = 3'd4;
    localparam [2:0] ST_LF     = 3'd5;

    localparam [4:0] FIELD_LAST = 5'd15;

    reg [2:0]  state_r;
    reg [3:0]  prefix_idx_r;
    reg [4:0]  field_idx_r;
    reg [3:0]  hex_idx_r;
    reg [31:0] field_latched_r [0:15];

    integer i;

    wire fire_w;
    assign fire_w = m_valid && m_ready;
    assign busy   = (state_r != ST_IDLE);

    function [7:0] hex_char;
        input [3:0] nibble;
        begin
            hex_char = (nibble < 4'd10) ? (8'h30 + {4'd0, nibble}) :
                                         (8'h41 + {4'd0, nibble - 4'd10});
        end
    endfunction

    function [7:0] word_hex_char;
        input [31:0] word;
        input [3:0]  pos;
        begin
            case (pos)
                4'd0: word_hex_char = hex_char(word[31:28]);
                4'd1: word_hex_char = hex_char(word[27:24]);
                4'd2: word_hex_char = hex_char(word[23:20]);
                4'd3: word_hex_char = hex_char(word[19:16]);
                4'd4: word_hex_char = hex_char(word[15:12]);
                4'd5: word_hex_char = hex_char(word[11:8]);
                4'd6: word_hex_char = hex_char(word[7:4]);
                default: word_hex_char = hex_char(word[3:0]);
            endcase
        end
    endfunction

    function [7:0] prefix_char;
        input [3:0] pos;
        begin
            case (pos)
                4'd0: prefix_char = 8'h53; // S
                4'd1: prefix_char = 8'h54; // T
                4'd2: prefix_char = 8'h41; // A
                4'd3: prefix_char = 8'h54; // T
                default: prefix_char = 8'h2C; // comma
            endcase
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r      <= ST_IDLE;
            prefix_idx_r <= 4'd0;
            field_idx_r  <= 5'd0;
            hex_idx_r    <= 4'd0;
            m_data       <= 8'd0;
            m_valid      <= 1'b0;
            for (i = 0; i < 16; i = i + 1)
                field_latched_r[i] <= 32'd0;
        end else begin
            if (state_r == ST_IDLE) begin
                m_valid <= 1'b0;
                if (start_pulse) begin
                    field_latched_r[0]  <= uptime_s;
                    field_latched_r[1]  <= rx_frame_count;
                    field_latched_r[2]  <= rx_drop_count;
                    field_latched_r[3]  <= tx_frame_count;
                    field_latched_r[4]  <= {24'd0, status_flags};
                    field_latched_r[5]  <= ptp_sync_count;
                    field_latched_r[6]  <= ptp_follow_up_count;
                    field_latched_r[7]  <= ptp_timeout_count;
                    field_latched_r[8]  <= ptp_sequence_id;
                    field_latched_r[9]  <= ptp_last_t1_low;
                    field_latched_r[10] <= tod_rx_sync_count;
                    field_latched_r[11] <= delay_req_count;
                    field_latched_r[12] <= delay_resp_count;
                    field_latched_r[13] <= delay_req_drop_count;
                    field_latched_r[14] <= delay_req_last_seq;
                    field_latched_r[15] <= delay_req_last_t4_low;
                    prefix_idx_r        <= 4'd0;
                    field_idx_r         <= 5'd0;
                    hex_idx_r           <= 4'd0;
                    m_data              <= prefix_char(4'd0);
                    m_valid             <= 1'b1;
                    state_r             <= ST_PREFIX;
                end
            end else if (!m_valid || fire_w) begin
                case (state_r)
                    ST_PREFIX: begin
                        if (prefix_idx_r == 4'd4) begin
                            state_r     <= ST_FIELD;
                            field_idx_r <= 5'd0;
                            hex_idx_r   <= 4'd0;
                            m_data      <= word_hex_char(field_latched_r[0], 4'd0);
                        end else begin
                            prefix_idx_r <= prefix_idx_r + 4'd1;
                            m_data       <= prefix_char(prefix_idx_r + 4'd1);
                        end
                        m_valid <= 1'b1;
                    end

                    ST_FIELD: begin
                        if (hex_idx_r == 4'd7) begin
                            if (field_idx_r == FIELD_LAST) begin
                                state_r <= ST_CR;
                                m_data  <= 8'h0D;
                            end else begin
                                state_r <= ST_COMMA;
                                m_data  <= 8'h2C;
                            end
                            hex_idx_r <= 4'd0;
                        end else begin
                            hex_idx_r <= hex_idx_r + 4'd1;
                            m_data    <= word_hex_char(field_latched_r[field_idx_r], hex_idx_r + 4'd1);
                        end
                        m_valid <= 1'b1;
                    end

                    ST_COMMA: begin
                        field_idx_r <= field_idx_r + 5'd1;
                        state_r     <= ST_FIELD;
                        hex_idx_r   <= 4'd0;
                        m_data      <= word_hex_char(field_latched_r[field_idx_r + 5'd1], 4'd0);
                        m_valid     <= 1'b1;
                    end

                    ST_CR: begin
                        state_r <= ST_LF;
                        m_data  <= 8'h0A;
                        m_valid <= 1'b1;
                    end

                    ST_LF: begin
                        state_r <= ST_IDLE;
                        m_valid <= 1'b0;
                    end

                    default: begin
                        state_r <= ST_IDLE;
                        m_valid <= 1'b0;
                    end
                endcase
            end
        end
    end

endmodule
`default_nettype wire
