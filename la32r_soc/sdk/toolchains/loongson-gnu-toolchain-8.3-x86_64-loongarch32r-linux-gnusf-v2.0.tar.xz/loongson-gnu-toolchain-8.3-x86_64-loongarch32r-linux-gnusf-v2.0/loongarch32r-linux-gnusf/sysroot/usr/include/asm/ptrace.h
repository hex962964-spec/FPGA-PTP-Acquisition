/* SPDX-License-Identifier: GPL-2.0+ WITH Linux-syscall-note */
/*
 * Author: Hanlu Li <lihanlu@loongson.cn>
 *         Huacai Chen <chenhuacai@loongson.cn>
 *
 * Copyright (C) 2020-2021 Loongson Technology Corporation Limited
 */
#ifndef _ASM_PTRACE_H
#define _ASM_PTRACE_H

#include <linux/types.h>

#include <stdint.h>

/* For PTRACE_{POKE,PEEK}USR. 0 - 31 are GPRs, 32 is PC, 33 is BADVADDR. */
#define GPR_BASE	0
#define GPR_NUM		32
#define GPR_END		(GPR_BASE + GPR_NUM - 1)
#define PC		(GPR_END + 1)
#define BADVADDR	(GPR_END + 2)

/*
 * This struct defines the way the registers are stored on the stack during a
 * system call/exception.
 *
 * If you add a register here, also add it to regoffset_table[] in
 * arch/loongarch/kernel/ptrace.c.
 */

struct user_pt_regs {
        /* Main processor registers. */
        unsigned long regs[32];

        /* Original syscall arg0. */
        unsigned long orig_a0;

        /* Special CSR registers. */
        unsigned long csr_era;
        unsigned long csr_badv;
        unsigned long reserved[10];
} __attribute__((aligned(8)));

struct user_fp_state {
        uint64_t fpr[32];
        uint64_t fcc;
        uint32_t fcsr;
};

struct user_lsx_state {
        /* 32 registers, 128 bits width per register. */
        uint64_t vregs[32*2];
};

struct user_lasx_state {
        /* 32 registers, 256 bits width per register. */
        uint64_t vregs[32*4];
};

#endif /* _ASM_PTRACE_H */
