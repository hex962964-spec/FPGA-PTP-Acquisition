`timescale 1ns / 1ps
`default_nettype none
//////////////////////////////////////////////////////////////////////////////////
// Module: ptp_tod_fabric
// Description:
//   三时钟域 ToD（Time of Day）时间基织构。
//
//   当前最小改动方案：
//     1) sys_clk 域保持原有行为，不改变 CSR / 前端时间语义；
//     2) eth_tx 域继续作为发送域权威 ToD；
//     3) eth_rx 域不再长期自由漂移，而是周期性镜像 eth_tx ToD，
//        从而让 RX 侧事件时间最终表达在同一个 DUT 本地时间基上；
//     4) 不改变模块对外端口，不影响 SoC 挂载与系统时钟树。
// 
//   设计原则：
//     - sys 域直接使用 CSR 原始脉冲，保持当前软件语义；
//     - eth_tx 域只使用通过 CDC 安全送达的 active 配置；
//     - eth_rx 域仍保留原有 set/step/freq 控制入口以维持兼容，
//       但会由 eth_tx authority 周期性重装，抑制 RX/TX 时间基漂移；
//     - 加入 timeout + reissue，避免 RX reset/relock 后 req/ack 卡死。
//////////////////////////////////////////////////////////////////////////////////
module ptp_tod_fabric(
    input  wire         clk_in,
    input  wire         resetn,
    input  wire         eth_tx_clk,
    input  wire         eth_tx_resetn,
    input  wire         eth_rx_clk,
    input  wire         eth_rx_resetn,

    // ------------------------------------------------------------------------
    // sys-domain direct control (kept exactly as current behavior)
    // ------------------------------------------------------------------------
    input  wire         cfg_ptp_enable,
    input  wire         cfg_ptp_hold,
    input  wire         cfg_ptp_update_pulse,
    input  wire         cfg_ptp_set_time_pulse,
    input  wire         cfg_ptp_step_pulse,
    input  wire [63:0]  cfg_ptp_set_time_ns,
    input  wire [31:0]  cfg_ptp_step_ns,
    input  wire [31:0]  cfg_ptp_freq_adj_ppb,

    // ------------------------------------------------------------------------
    // eth_tx-domain active config from ptp_cfg_cmd_manager
    // ------------------------------------------------------------------------
    input  wire         tx_cfg_enable_eth,
    input  wire         tx_cfg_hold_eth,
    input  wire         tx_cfg_update_pulse_eth,
    input  wire         tx_cfg_set_time_pulse_eth,
    input  wire         tx_cfg_step_pulse_eth,
    input  wire [63:0]  tx_cfg_set_time_ns_eth,
    input  wire [31:0]  tx_cfg_step_ns_eth,
    input  wire [31:0]  tx_cfg_freq_adj_ppb_eth,

    // ------------------------------------------------------------------------
    // eth_rx-domain active config from ptp_cfg_cmd_manager
    // ------------------------------------------------------------------------
    input  wire         rx_tod_enable_eth,
    input  wire         rx_tod_hold_eth,
    input  wire         rx_tod_update_pulse_eth,
    input  wire         rx_tod_set_time_pulse_eth,
    input  wire         rx_tod_step_pulse_eth,
    input  wire [63:0]  rx_tod_set_time_ns_eth,
    input  wire [31:0]  rx_tod_step_ns_eth,
    input  wire [31:0]  rx_tod_freq_adj_ppb_eth,

    // ------------------------------------------------------------------------
    // Per-domain ToD outputs
    // ------------------------------------------------------------------------
    output wire [63:0]  ptp_sys_tod_time_ns,
    output wire         ptp_sys_tod_time_valid,
    output wire [63:0]  ptp_tod_time_ns_eth,
    output wire         ptp_tod_time_valid_eth,
    output wire [63:0]  ptp_tod_time_ns_rx,
    output wire         ptp_tod_time_valid_rx
);

    // ------------------------------------------------------------------------
    // Local constants for the minimal RX-mirror scheme.
    // - 125 MHz eth clock => 125000 cycles per 1 ms
    // - timeout 10 ms => 1250000 cycles
    // ------------------------------------------------------------------------
    localparam integer C_RX_SYNC_INTERVAL_CYCLES = 32'd125000;
    localparam integer C_RX_ACK_TIMEOUT_CYCLES   = 32'd1250000;
    localparam integer C_RX_LOAD_COMP_NS         = 0;

    // ------------------------------------------------------------------------
    // Helper: optional fixed compensation when loading the RX mirror.
    // This is kept at 0 by default, but the hook is left in place so later
    // board-level calibration does not require structural RTL edits.
    // ------------------------------------------------------------------------
    function [63:0] f_apply_rx_load_comp;
        input [63:0] i_time_ns;
        reg signed [64:0] tmp_v;
        begin
            if (C_RX_LOAD_COMP_NS >= 0)
                tmp_v = $signed({1'b0, i_time_ns}) + $signed(C_RX_LOAD_COMP_NS);
            else
                tmp_v = $signed({1'b0, i_time_ns}) - $signed(-C_RX_LOAD_COMP_NS);

            if (tmp_v[64])
                f_apply_rx_load_comp = 64'd0;
            else
                f_apply_rx_load_comp = tmp_v[63:0];
        end
    endfunction

    // ------------------------------------------------------------------------
    // sys-domain ToD counter (unchanged)
    // ------------------------------------------------------------------------
    ptp_tod_counter #(
        .P_TIME_W       (64),
        .P_FRAC_W       (16),
        .P_ADJ_W        (32),
        .P_NS_PER_CYCLE (20),
        .P_INIT_VALID   (0)
    ) u_ptp_tod_counter_sys (
        .clk              (clk_in),
        .rst_n            (resetn),
        .cfg_enable       (cfg_ptp_enable),
        .cfg_hold         (cfg_ptp_hold),
        .set_valid        (cfg_ptp_set_time_pulse),
        .set_time_ns      (cfg_ptp_set_time_ns),
        .step_valid       (cfg_ptp_step_pulse),
        .step_ns          (cfg_ptp_step_ns),
        .freq_adj_valid   (cfg_ptp_update_pulse),
        .freq_adj_ppb     (cfg_ptp_freq_adj_ppb),
        .tod_time_ns      (ptp_sys_tod_time_ns),
        .tod_time_frac    (),
        .tod_time_valid   (ptp_sys_tod_time_valid),
        .freq_adj_ppb_cur (),
        .pps_pulse        ()
    );

    // ------------------------------------------------------------------------
    // eth_tx-domain authority ToD counter (unchanged)
    // ------------------------------------------------------------------------
    ptp_tod_counter #(
        .P_TIME_W       (64),
        .P_FRAC_W       (16),
        .P_ADJ_W        (32),
        .P_NS_PER_CYCLE (8),
        .P_INIT_VALID   (0)
    ) u_ptp_tod_counter_eth (
        .clk              (eth_tx_clk),
        .rst_n            (eth_tx_resetn),
        .cfg_enable       (tx_cfg_enable_eth),
        .cfg_hold         (tx_cfg_hold_eth),
        .set_valid        (tx_cfg_update_pulse_eth && tx_cfg_set_time_pulse_eth),
        .set_time_ns      (tx_cfg_set_time_ns_eth),
        .step_valid       (tx_cfg_update_pulse_eth && tx_cfg_step_pulse_eth),
        .step_ns          (tx_cfg_step_ns_eth),
        .freq_adj_valid   (tx_cfg_update_pulse_eth),
        .freq_adj_ppb     (tx_cfg_freq_adj_ppb_eth),
        .tod_time_ns      (ptp_tod_time_ns_eth),
        .tod_time_frac    (),
        .tod_time_valid   (ptp_tod_time_valid_eth),
        .freq_adj_ppb_cur (),
        .pps_pulse        ()
    );

    // ------------------------------------------------------------------------
    // TX authority -> RX mirror CDC state
    // ------------------------------------------------------------------------
    reg  [63:0] tx_snapshot_ns_r;
    reg         tx_req_toggle_r;
    reg         tx_req_seen_ack_r;
    reg         tx_initial_sync_done_r;
    reg         tx_force_sync_r;
    reg         rx_sync_pending_r;
    reg  [31:0] tx_sync_interval_cnt_r;
    reg  [31:0] tx_sync_timeout_cnt_r;

    (* ASYNC_REG = "TRUE", SHREG_EXTRACT = "NO" *) reg [1:0] tx_ack_toggle_sync_r;
    wire tx_ack_event_w;
    wire tx_periodic_sync_due_w;
    wire tx_launch_sync_req_w;

    (* ASYNC_REG = "TRUE", SHREG_EXTRACT = "NO" *) reg [1:0] rx_req_toggle_sync_r;
    reg  rx_req_seen_r;
    reg  rx_ack_toggle_r;
    reg  rx_mirror_set_valid_r;
    reg  [63:0] rx_mirror_set_time_ns_r;

    // Direct software-driven RX control is preserved for compatibility.
    wire        rx_direct_set_valid_w;
    wire        rx_direct_step_valid_w;
    wire        rx_counter_set_valid_w;
    wire [63:0] rx_counter_set_time_ns_w;

    assign tx_ack_event_w        = (tx_ack_toggle_sync_r[1] ^ tx_req_seen_ack_r);
    assign tx_periodic_sync_due_w= (tx_sync_interval_cnt_r >= (C_RX_SYNC_INTERVAL_CYCLES - 1));
    assign tx_launch_sync_req_w  = !rx_sync_pending_r &&
                                   ptp_tod_time_valid_eth &&
                                   (tx_force_sync_r || !tx_initial_sync_done_r || tx_periodic_sync_due_w);

    assign rx_direct_set_valid_w   = rx_tod_update_pulse_eth && rx_tod_set_time_pulse_eth;
    assign rx_direct_step_valid_w  = rx_tod_update_pulse_eth && rx_tod_step_pulse_eth;
    assign rx_counter_set_valid_w  = rx_direct_set_valid_w || rx_mirror_set_valid_r;
    assign rx_counter_set_time_ns_w=
        rx_mirror_set_valid_r ? rx_mirror_set_time_ns_r : rx_tod_set_time_ns_eth;

    // ------------------------------------------------------------------------
    // eth_tx domain: generate and manage periodic mirror requests.
    // ------------------------------------------------------------------------
    always @(posedge eth_tx_clk or negedge eth_tx_resetn) begin
        if (!eth_tx_resetn) begin
            tx_snapshot_ns_r       <= 64'd0;
            tx_req_toggle_r        <= 1'b0;
            tx_req_seen_ack_r      <= 1'b0;
            tx_initial_sync_done_r <= 1'b0;
            tx_force_sync_r        <= 1'b0;
            rx_sync_pending_r      <= 1'b0;
            tx_sync_interval_cnt_r <= 32'd0;
            tx_sync_timeout_cnt_r  <= 32'd0;
            tx_ack_toggle_sync_r   <= 2'b00;
        end else begin
            tx_ack_toggle_sync_r <= {tx_ack_toggle_sync_r[0], rx_ack_toggle_r};

            if (tx_cfg_update_pulse_eth)
                tx_force_sync_r <= 1'b1;

            if (tx_ack_event_w) begin
                tx_req_seen_ack_r      <= tx_ack_toggle_sync_r[1];
                tx_initial_sync_done_r <= 1'b1;
                tx_force_sync_r        <= 1'b0;
                rx_sync_pending_r      <= 1'b0;
                tx_sync_interval_cnt_r <= 32'd0;
                tx_sync_timeout_cnt_r  <= 32'd0;
            end else if (rx_sync_pending_r) begin
                if (tx_sync_timeout_cnt_r >= (C_RX_ACK_TIMEOUT_CYCLES - 1)) begin
                    // RX mirror ACK timeout: keep the same external contract,
                    // but re-issue a fresh authority snapshot to break CDC deadlock
                    // after RX reset/relock.
                    tx_snapshot_ns_r       <= ptp_tod_time_ns_eth;
                    tx_req_toggle_r        <= ~tx_req_toggle_r;
                    tx_sync_timeout_cnt_r  <= 32'd0;
                end else begin
                    tx_sync_timeout_cnt_r <= tx_sync_timeout_cnt_r + 32'd1;
                end
            end else if (tx_launch_sync_req_w) begin
                tx_snapshot_ns_r       <= ptp_tod_time_ns_eth;
                tx_req_toggle_r        <= ~tx_req_toggle_r;
                rx_sync_pending_r      <= 1'b1;
                tx_sync_interval_cnt_r <= 32'd0;
                tx_sync_timeout_cnt_r  <= 32'd0;
            end else if (ptp_tod_time_valid_eth) begin
                tx_sync_interval_cnt_r <= tx_sync_interval_cnt_r + 32'd1;
            end
        end
    end

    // ------------------------------------------------------------------------
    // eth_rx domain: consume mirror requests and pulse local set_time.
    // ------------------------------------------------------------------------
    always @(posedge eth_rx_clk or negedge eth_rx_resetn) begin
        if (!eth_rx_resetn) begin
            rx_req_toggle_sync_r   <= 2'b00;
            rx_req_seen_r          <= 1'b0;
            rx_ack_toggle_r        <= 1'b0;
            rx_mirror_set_valid_r  <= 1'b0;
            rx_mirror_set_time_ns_r<= 64'd0;
        end else begin
            rx_req_toggle_sync_r  <= {rx_req_toggle_sync_r[0], tx_req_toggle_r};
            rx_mirror_set_valid_r <= 1'b0;

            if (rx_req_toggle_sync_r[1] ^ rx_req_seen_r) begin
                rx_req_seen_r           <= rx_req_toggle_sync_r[1];
                rx_mirror_set_time_ns_r <= f_apply_rx_load_comp(tx_snapshot_ns_r);
                rx_mirror_set_valid_r   <= 1'b1;
                rx_ack_toggle_r         <= ~rx_ack_toggle_r;
            end
        end
    end

    // ------------------------------------------------------------------------
    // eth_rx-domain ToD counter
    // Compatibility note:
    //   - direct RX set/step/freq inputs are still accepted;
    //   - authority mirror set_time has higher priority when both happen together.
    // ------------------------------------------------------------------------
    ptp_tod_counter #(
        .P_TIME_W       (64),
        .P_FRAC_W       (16),
        .P_ADJ_W        (32),
        .P_NS_PER_CYCLE (8),
        .P_INIT_VALID   (0)
    ) u_ptp_tod_counter_rx (
        .clk              (eth_rx_clk),
        .rst_n            (eth_rx_resetn),
        .cfg_enable       (rx_tod_enable_eth),
        .cfg_hold         (rx_tod_hold_eth),
        .set_valid        (rx_counter_set_valid_w),
        .set_time_ns      (rx_counter_set_time_ns_w),
        .step_valid       (rx_direct_step_valid_w),
        .step_ns          (rx_tod_step_ns_eth),
        .freq_adj_valid   (rx_tod_update_pulse_eth),
        .freq_adj_ppb     (rx_tod_freq_adj_ppb_eth),
        .tod_time_ns      (ptp_tod_time_ns_rx),
        .tod_time_frac    (),
        .tod_time_valid   (ptp_tod_time_valid_rx),
        .freq_adj_ppb_cur (),
        .pps_pulse        ()
    );

endmodule

`default_nettype wire
