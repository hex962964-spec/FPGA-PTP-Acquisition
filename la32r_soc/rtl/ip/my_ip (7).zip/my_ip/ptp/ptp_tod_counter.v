`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module: ptp_tod_counter
// -----------------------------------------------------------------------------
// 作用：
//   1) 提供一个“以纳秒为整数输出、内部带小数累加”的 ToD（time-of-day）计数器。
//   2) 支持 set_time / step_adjust / freq_adjust 三类基础校时动作。
//   3) 作为 sys_clk 域或 eth_tx_clk / eth_rx_clk 域的本地时间基使用。
//
// 设计取舍：
//   - 输出接口统一为 tod_time_ns（整数纳秒），便于当前 wrapper / CSR 直接使用。
//   - 内部使用 fixed-point（Q ns）累加，保留频率微调余量。
//   - PTP_FREQ_ADJ 的统一语义定义为：signed ppb（parts-per-billion）。
//     也就是“相对名义频率的十亿分之一频偏”，三域共享同一语义，
//     域内再根据本域 P_NS_PER_CYCLE 自动换算为 fixed-point ns/tick 增量。
//   - 这样软件 servo 只维护一个频偏概念，不会再出现 20ns/tick 和 8ns/tick
//     对同一寄存器值产生不同相对调频幅度的问题。
//
// 推荐用法：
//   - 50MHz sys_clk 域：P_NS_PER_CYCLE = 20
//   - 125MHz eth_clk 域：P_NS_PER_CYCLE = 8
//
// 预留扩展：
//   - pps_pulse 便于后续做秒边界观测/调试（默认可关闭以节省逻辑）。
//   - tod_time_frac 便于后续做更细粒度的时间对齐或 debug。
//////////////////////////////////////////////////////////////////////////////////
module ptp_tod_counter #(
    parameter integer P_TIME_W        = 64,
    parameter integer P_FRAC_W        = 16,
    parameter integer P_ADJ_W         = 32,
    parameter integer P_NS_PER_CYCLE  = 8,
    parameter integer P_ENABLE_PPS    = 0,
    parameter [P_TIME_W-1:0] P_INIT_TIME_NS = {P_TIME_W{1'b0}},
    parameter integer P_INIT_VALID    = 1
)(
    input  wire                         clk,
    input  wire                         rst_n,

    // ------------------------------------------------------------------------
    // 基本运行控制
    // ------------------------------------------------------------------------
    input  wire                         cfg_enable,
    input  wire                         cfg_hold,

    // ------------------------------------------------------------------------
    // 时间装载：直接把当前 ToD 设置为 set_time_ns
    // ------------------------------------------------------------------------
    input  wire                         set_valid,
    input  wire [P_TIME_W-1:0]          set_time_ns,

    // ------------------------------------------------------------------------
    // 步进修正：在当前 ToD 基础上加/减一个离散量
    // step_ns 为有符号整数纳秒
    // ------------------------------------------------------------------------
    input  wire                         step_valid,
    input  wire signed [31:0]           step_ns,

    // ------------------------------------------------------------------------
    // 频率修正：统一语义为 signed ppb
    // 例：
    //   +1000 -> 本地时钟相对名义频率加快 1000 ppb
    //   -250  -> 本地时钟相对名义频率减慢 250 ppb
    // ------------------------------------------------------------------------
    input  wire                         freq_adj_valid,
    input  wire signed [P_ADJ_W-1:0]    freq_adj_ppb,

    // ------------------------------------------------------------------------
    // 输出当前 ToD
    // ------------------------------------------------------------------------
    output wire [P_TIME_W-1:0]          tod_time_ns,
    output wire [P_FRAC_W-1:0]          tod_time_frac,
    output reg                          tod_time_valid,

    // 当前生效的 ppb 调整值（回读/debug 用）
    output reg  signed [P_ADJ_W-1:0]    freq_adj_ppb_cur,

    // 整秒脉冲（整数纳秒跨过 1s 边界时拉高 1 拍）
    output reg                          pps_pulse
);

    localparam integer C_FP_W = P_TIME_W + P_FRAC_W;

    // 注意：这里的 base increment 仅用于“名义每拍增加多少 fixed-point ns”。
    // P_NS_PER_CYCLE 当前只取 8 / 20，因此 32 位足够容纳。
    localparam integer C_BASE_INC_FP_INT = (P_NS_PER_CYCLE << P_FRAC_W);
    localparam integer C_RECIP_SHIFT     = 48;
    localparam signed [31:0] C_RECIP_1E9_Q48 = 32'sd281475;
    localparam signed [95:0] C_RECIP_ROUND_Q48 = 96'sd140737488355328; // 2^47

    // fixed-point ToD：高位是整数纳秒，低 P_FRAC_W 位是小数部分
    reg signed [C_FP_W-1:0] tod_fp_r;

    // 当前生效的“每 tick 额外 fixed-point ns 增量”
    reg signed [P_ADJ_W-1:0] freq_adj_fp_tick_r;

    wire [P_TIME_W-1:0] tod_time_ns_w;
    assign tod_time_ns_w = tod_fp_r[C_FP_W-1:P_FRAC_W];

    assign tod_time_ns   = tod_time_ns_w;
    assign tod_time_frac = tod_fp_r[P_FRAC_W-1:0];

    // ------------------------------------------------------------------------
    // helper: 无符号整数纳秒 -> fixed-point
    // ------------------------------------------------------------------------
    function [C_FP_W-1:0] f_uint_ns_to_fp;
        input integer i_ns;
        reg [C_FP_W-1:0] tmp;
        begin
            tmp = {C_FP_W{1'b0}};
            tmp = i_ns;
            f_uint_ns_to_fp = tmp << P_FRAC_W;
        end
    endfunction

    // ------------------------------------------------------------------------
    // helper: signed ppb -> signed fixed-point ns/tick
    // 公式：delta_fp_per_tick = (base_inc_fp * ppb) / 1e9
    // 这里使用 Q48 reciprocal 近似 1/1e9，避免在硬件中引入大位宽除法器。
    // ------------------------------------------------------------------------
    function signed [P_ADJ_W-1:0] f_ppb_to_fp_tick;
        input signed [P_ADJ_W-1:0] i_ppb;
        reg signed [63:0]  base_mul_ppb_v;
        reg signed [95:0]  recip_mul_v;
        reg        [95:0]  recip_abs_v;
        reg        [95:0]  recip_abs_round_v;
        begin
            base_mul_ppb_v = $signed(i_ppb) * $signed(C_BASE_INC_FP_INT);
            recip_mul_v    = $signed(base_mul_ppb_v) * $signed(C_RECIP_1E9_Q48);

            if (recip_mul_v < 0)
                recip_abs_v = -recip_mul_v;
            else
                recip_abs_v = recip_mul_v;

            recip_abs_round_v = (recip_abs_v + C_RECIP_ROUND_Q48) >> C_RECIP_SHIFT;

            if (recip_mul_v < 0)
                f_ppb_to_fp_tick = -$signed(recip_abs_round_v);
            else
                f_ppb_to_fp_tick =  $signed(recip_abs_round_v);
        end
    endfunction

    localparam [C_FP_W-1:0] C_BASE_INC_FP = f_uint_ns_to_fp(P_NS_PER_CYCLE);
    localparam [C_FP_W-1:0] C_ONE_SEC_FP  = f_uint_ns_to_fp(1000000000);

    wire signed [C_FP_W-1:0] step_fp_w =
        $signed({{(C_FP_W-32){step_ns[31]}}, step_ns}) <<< P_FRAC_W;

    wire signed [C_FP_W-1:0] freq_adj_ext_w =
        $signed({{(C_FP_W-P_ADJ_W){freq_adj_fp_tick_r[P_ADJ_W-1]}}, freq_adj_fp_tick_r});

    // 为避免在每个时钟都做除法/模运算，额外维护“1 秒内的 sub-second fixed-point 位置”。
    reg signed [C_FP_W-1:0] subsec_fp_r;

    always @(posedge clk or negedge rst_n) begin : TOD_MAIN
        reg signed [C_FP_W:0] next_fp_v;
        reg signed [C_FP_W:0] delta_fp_v;
        reg signed [C_FP_W:0] next_subsec_v;
        if (!rst_n) begin
            tod_fp_r            <= $signed({P_INIT_TIME_NS, {P_FRAC_W{1'b0}}});
            subsec_fp_r         <= $signed({(P_INIT_TIME_NS % 1000000000), {P_FRAC_W{1'b0}}});
            tod_time_valid      <= (P_INIT_VALID != 0);
            freq_adj_ppb_cur    <= {P_ADJ_W{1'b0}};
            freq_adj_fp_tick_r  <= {P_ADJ_W{1'b0}};
            pps_pulse           <= 1'b0;
        end else begin
            pps_pulse <= 1'b0;

            if (freq_adj_valid) begin
                freq_adj_ppb_cur   <= freq_adj_ppb;
                freq_adj_fp_tick_r <= f_ppb_to_fp_tick(freq_adj_ppb);
            end

            if (set_valid) begin
                tod_fp_r       <= $signed({set_time_ns, {P_FRAC_W{1'b0}}});
                subsec_fp_r    <= $signed({(set_time_ns % 1000000000), {P_FRAC_W{1'b0}}});
                tod_time_valid <= 1'b1;
            end else if (step_valid) begin
                next_fp_v = $signed({1'b0, tod_fp_r}) + $signed({step_fp_w[C_FP_W-1], step_fp_w});
                if (next_fp_v < 0)
                    tod_fp_r <= {C_FP_W{1'b0}};
                else
                    tod_fp_r <= next_fp_v[C_FP_W-1:0];

                // step 属于低频配置动作，这里直接允许一次取模来重建 sub-second 位置
                if (next_fp_v < 0)
                    subsec_fp_r <= {C_FP_W{1'b0}};
                else
                    subsec_fp_r <= $signed({(next_fp_v[C_FP_W-1:P_FRAC_W] % 1000000000), {P_FRAC_W{1'b0}}});
            end else if (cfg_enable && !cfg_hold) begin
                delta_fp_v = $signed({1'b0, C_BASE_INC_FP}) +
                             $signed({freq_adj_ext_w[C_FP_W-1], freq_adj_ext_w});
                next_fp_v  = $signed({1'b0, tod_fp_r}) + delta_fp_v;

                if (next_fp_v < 0)
                    tod_fp_r <= {C_FP_W{1'b0}};
                else
                    tod_fp_r <= next_fp_v[C_FP_W-1:0];

                next_subsec_v = $signed({1'b0, subsec_fp_r}) + delta_fp_v;
                if (next_subsec_v >= $signed({1'b0, C_ONE_SEC_FP})) begin
                    subsec_fp_r <= next_subsec_v[C_FP_W-1:0] - C_ONE_SEC_FP;
                    if ((P_ENABLE_PPS != 0) && tod_time_valid)
                        pps_pulse <= 1'b1;
                end else if (next_subsec_v < 0) begin
                    // 允许小幅负频率修正；若越过 0 边界，则借 1 秒回来。
                    subsec_fp_r <= next_subsec_v[C_FP_W-1:0] + C_ONE_SEC_FP;
                end else begin
                    subsec_fp_r <= next_subsec_v[C_FP_W-1:0];
                end
            end
        end
    end

endmodule
