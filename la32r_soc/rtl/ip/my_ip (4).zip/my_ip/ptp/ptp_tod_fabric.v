`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module: ptp_tod_fabric
// Description:
//   三时钟域 ToD（Time of Day）时间基织构。
//
//   该模块只负责 PTP 时间基本身，不掺杂 TX/RX 数据路径或 CSR 命令状态机：
//     1) sys_clk  域：供 CSR 读回、前端时间戳源选择使用；
//     2) eth_tx   域：作为发送域的权威 ToD；
//     3) eth_rx   域：作为接收域的本地 ToD。
//
//   设计原则：
//     - sys 域直接使用 CSR 原始脉冲，保持你现在的软件语义；
//     - eth_tx / eth_rx 域只使用已经通过 CDC 安全送达的 active 配置；
//     - 不改 PTP_FREQ_ADJ / set_time / step 的既有行为。
//////////////////////////////////////////////////////////////////////////////////
module ptp_tod_fabric(
    input  wire         clk_in,
    input  wire         resetn,
    input  wire         eth_tx_clk,
    input  wire         eth_tx_resetn,
    input  wire         eth_rx_clk,
    input  wire         eth_rx_resetn,

    // ------------------------------------------------------------------------
    // sys-domain direct control (kept exactly as current behavior)
    // ------------------------------------------------------------------------
    input  wire         cfg_ptp_enable,
    input  wire         cfg_ptp_hold,
    input  wire         cfg_ptp_update_pulse,
    input  wire         cfg_ptp_set_time_pulse,
    input  wire         cfg_ptp_step_pulse,
    input  wire [63:0]  cfg_ptp_set_time_ns,
    input  wire [31:0]  cfg_ptp_step_ns,
    input  wire [31:0]  cfg_ptp_freq_adj_ppb,

    // ------------------------------------------------------------------------
    // eth_tx-domain active config from ptp_cfg_cmd_manager
    // ------------------------------------------------------------------------
    input  wire         tx_cfg_enable_eth,
    input  wire         tx_cfg_hold_eth,
    input  wire         tx_cfg_update_pulse_eth,
    input  wire         tx_cfg_set_time_pulse_eth,
    input  wire         tx_cfg_step_pulse_eth,
    input  wire [63:0]  tx_cfg_set_time_ns_eth,
    input  wire [31:0]  tx_cfg_step_ns_eth,
    input  wire [31:0]  tx_cfg_freq_adj_ppb_eth,

    // ------------------------------------------------------------------------
    // eth_rx-domain active config from ptp_cfg_cmd_manager
    // ------------------------------------------------------------------------
    input  wire         rx_tod_enable_eth,
    input  wire         rx_tod_hold_eth,
    input  wire         rx_tod_update_pulse_eth,
    input  wire         rx_tod_set_time_pulse_eth,
    input  wire         rx_tod_step_pulse_eth,
    input  wire [63:0]  rx_tod_set_time_ns_eth,
    input  wire [31:0]  rx_tod_step_ns_eth,
    input  wire [31:0]  rx_tod_freq_adj_ppb_eth,

    // ------------------------------------------------------------------------
    // Per-domain ToD outputs
    // ------------------------------------------------------------------------
    output wire [63:0]  ptp_sys_tod_time_ns,
    output wire         ptp_sys_tod_time_valid,
    output wire [63:0]  ptp_tod_time_ns_eth,
    output wire         ptp_tod_time_valid_eth,
    output wire [63:0]  ptp_tod_time_ns_rx,
    output wire         ptp_tod_time_valid_rx
);

    // ------------------------------------------------------------------------
    // sys-domain ToD counter
    // ------------------------------------------------------------------------
    ptp_tod_counter #(
        .P_TIME_W       (64),
        .P_FRAC_W       (16),
        .P_ADJ_W        (32),
        .P_NS_PER_CYCLE (20)
    ) u_ptp_tod_counter_sys (
        .clk              (clk_in),
        .rst_n            (resetn),
        .cfg_enable       (cfg_ptp_enable),
        .cfg_hold         (cfg_ptp_hold),
        .set_valid        (cfg_ptp_set_time_pulse),
        .set_time_ns      (cfg_ptp_set_time_ns),
        .step_valid       (cfg_ptp_step_pulse),
        .step_ns          (cfg_ptp_step_ns),
        .freq_adj_valid   (cfg_ptp_update_pulse),
        .freq_adj_ppb     (cfg_ptp_freq_adj_ppb),
        .tod_time_ns      (ptp_sys_tod_time_ns),
        .tod_time_frac    (),
        .tod_time_valid   (ptp_sys_tod_time_valid),
        .freq_adj_ppb_cur (),
        .pps_pulse        ()
    );

    // ------------------------------------------------------------------------
    // eth_tx-domain ToD counter
    // ------------------------------------------------------------------------
    ptp_tod_counter #(
        .P_TIME_W       (64),
        .P_FRAC_W       (16),
        .P_ADJ_W        (32),
        .P_NS_PER_CYCLE (8)
    ) u_ptp_tod_counter_eth (
        .clk              (eth_tx_clk),
        .rst_n            (eth_tx_resetn),
        .cfg_enable       (tx_cfg_enable_eth),
        .cfg_hold         (tx_cfg_hold_eth),
        .set_valid        (tx_cfg_update_pulse_eth && tx_cfg_set_time_pulse_eth),
        .set_time_ns      (tx_cfg_set_time_ns_eth),
        .step_valid       (tx_cfg_update_pulse_eth && tx_cfg_step_pulse_eth),
        .step_ns          (tx_cfg_step_ns_eth),
        .freq_adj_valid   (tx_cfg_update_pulse_eth),
        .freq_adj_ppb     (tx_cfg_freq_adj_ppb_eth),
        .tod_time_ns      (ptp_tod_time_ns_eth),
        .tod_time_frac    (),
        .tod_time_valid   (ptp_tod_time_valid_eth),
        .freq_adj_ppb_cur (),
        .pps_pulse        ()
    );

    // ------------------------------------------------------------------------
    // eth_rx-domain ToD counter
    // ------------------------------------------------------------------------
    ptp_tod_counter #(
        .P_TIME_W       (64),
        .P_FRAC_W       (16),
        .P_ADJ_W        (32),
        .P_NS_PER_CYCLE (8)
    ) u_ptp_tod_counter_rx (
        .clk              (eth_rx_clk),
        .rst_n            (eth_rx_resetn),
        .cfg_enable       (rx_tod_enable_eth),
        .cfg_hold         (rx_tod_hold_eth),
        .set_valid        (rx_tod_update_pulse_eth && rx_tod_set_time_pulse_eth),
        .set_time_ns      (rx_tod_set_time_ns_eth),
        .step_valid       (rx_tod_update_pulse_eth && rx_tod_step_pulse_eth),
        .step_ns          (rx_tod_step_ns_eth),
        .freq_adj_valid   (rx_tod_update_pulse_eth),
        .freq_adj_ppb     (rx_tod_freq_adj_ppb_eth),
        .tod_time_ns      (ptp_tod_time_ns_rx),
        .tod_time_frac    (),
        .tod_time_valid   (ptp_tod_time_valid_rx),
        .freq_adj_ppb_cur (),
        .pps_pulse        ()
    );

endmodule
